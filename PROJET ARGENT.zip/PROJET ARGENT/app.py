from flask import Flask, render_template, request, redirect, url_for
import sqlite3
from flask_mail import Mail, Message
app = Flask(__name__)
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'transfertangerado@gmail.com'
app.config['MAIL_PASSWORD'] = 'Angeradotransfert02'

mail = Mail(app)


# Créer la base de données
def init_db():
    conn = sqlite3.connect('transfert.db')
    c = conn.cursor()

    # Table des utilisateurs
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            verification_code TEXT,
            is_verified INTEGER DEFAULT 0
        )
    ''')
    
    c.execute('''
    CREATE TABLE IF NOT EXISTS wallets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        currency TEXT NOT NULL,
        balance REAL DEFAULT 0,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )
''')

    # Table des soldes
    c.execute('''
        CREATE TABLE IF NOT EXISTS balances (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            currency TEXT NOT NULL,
            amount REAL DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')

    conn.commit()
    conn.close()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register_form')
def register_form():
    return render_template('register.html')

@app.route('/register', methods=['POST'])
def register():
    name = request.form['name']
    email = request.form['email']
    password = request.form['password']
    
    import random
    import string
    import sqlite3
    from flask import redirect, url_for
    from flask_mail import Message

    verification_code = ''.join(random.         choices(string.digits, k=6))  # exemple : 123456

    conn = sqlite3.connect('transfert.db')
    c = conn.cursor()

    try:
           c.execute("INSERT INTO users (name, email, password, verification_code) VALUES (?, ?, ?, ?)",
              (name, email, password, verification_code))
           conn.commit()

           msg = Message('Code de vérification', sender='transfertangerado@gmail.com', recipients=[email])
           try:
                 msg.body = f'Votre code de vérification est : {verification_code}'
                 mail.send(msg)
               except Exception as e:
                     print("Erreur lors de l'envoi de l'email :", e)

               return redirect(url_for('verify', email=email))

          except sqlite3.IntegrityError:
                return "Cet email est déjà utilisé."

          finally:
                conn.close()


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        conn = sqlite3.connect('transfert.db')
        c = conn.cursor()
        c.execute("SELECT password, is_verified FROM users WHERE email = ?", (email,))
        result = c.fetchone()
        conn.close()

        if result:
            db_password, is_verified = result
            if password == db_password:
                if is_verified:
                    return "Connexion réussie !"  # Tu peux rediriger vers la page d’accueil ici
                else:
                    return "Compte non vérifié. Veuillez vérifier votre adresse email."
            else:
                return "Mot de passe incorrect."
            else:
                return "Email introuvable."

          if user and user[3] == 1:
            
                return render_template('login.html', error="Identifiants incorrects ou compte non vérifié")

  return render_template('login.html')

@app.route('/dashboard/<int:user_id>')
def dashboard(user_id):
    conn = sqlite3.connect('transfert.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    c.execute("SELECT id, name FROM users WHERE id = ?", (user_id,))
    user = c.fetchone()
    
    wallets = []
    if user:
        c.execute("SELECT currency, balance FROM wallets WHERE user_id = ?", (user_id,))
        wallets = c.fetchall()
    conn.close()

    return render_template('dashboard.html', username=user['name'], wallets=wallets)
    
@app.route('/add_currency/<int:user_id>', methods=['POST'])
def add_currency(user_id):
    currency = request.form['currency']

    conn = sqlite3.connect('transfert.db')
    c = conn.cursor()

    # Récupérer l'id de l'utilisateur
    c.execute("SELECT name FROM users WHERE id = ?", (user_id,))
    user = c.fetchone()

    # Vérifie si la devise existe déjà
    c.execute("SELECT * FROM wallets WHERE user_id = ? AND currency = ?", (user_id, currency))
    exists = c.fetchone()
    
    if not exists:
        c.execute("INSERT INTO wallets (user_id, currency) VALUES (?, ?)", (user_id, currency))
        conn.commit()

    conn.close()
    return redirect(f"/dashboard/{user_id}")
    
@app.route('/send_money_form/<username>')
def send_money_form(username):
    return render_template('send_money.html', username=username)

@app.route('/send_money', methods=['POST'])
def send_money():
    sender = request.form['sender']
    recipient = request.form['recipient']
    currency = request.form['currency']
    amount = float(request.form['amount'])

    conn = sqlite3.connect('transfert.db')
    c = conn.cursor()

    # Vérifier les IDs
    c.execute("SELECT id FROM users WHERE name = ?", (sender,))
    sender_id = c.fetchone()

    c.execute("SELECT id FROM users WHERE name = ?", (recipient,))
    recipient_id = c.fetchone()

    if not sender_id or not recipient_id:
        conn.close()
        return "Utilisateur introuvable."

    # Vérifier solde du sender
    c.execute("SELECT balance FROM wallets WHERE user_id = ? AND currency = ?", (sender_id[0], currency))
    sender_balance = c.fetchone()

    if not sender_balance or sender_balance[0] < amount:
        conn.close()
        return "Solde insuffisant."

    # Débiter sender
    c.execute("UPDATE wallets SET balance = balance - ? WHERE user_id = ? AND currency = ?",
              (amount, sender_id[0], currency))

    # Créditer recipient (créer la devise si elle n'existe pas)
    c.execute("SELECT balance FROM wallets WHERE user_id = ? AND currency = ?", (recipient_id[0], currency))
    recipient_wallet = c.fetchone()
    if recipient_wallet:
        c.execute("UPDATE wallets SET balance = balance + ? WHERE user_id = ? AND currency = ?",
                  (amount, recipient_id[0], currency))
    else:
        c.execute("INSERT INTO wallets (user_id, currency, balance) VALUES (?, ?, ?)",
                  (recipient_id[0], currency, amount))

    conn.commit()
    conn.close()

    return redirect(f"/dashboard/{sender_id[0]}")
    
@app.route('/verify_code', methods=['POST'])
def verify_code():
    code_entered = request.form['code']
    email = request.form['email']

    conn = sqlite3.connect('transfert.db')
    c = conn.cursor()
    c.execute("SELECT verification_code FROM users WHERE email = ?", (email,))
    result = c.fetchone()

    if result and result[0] == code_entered:
        # Code correct : on vérifie le compte
        c.execute("UPDATE users SET is_verified = 1 WHERE email = ?", (email,))
        conn.commit()
        conn.close()
        return redirect(url_for('login'))
    else:
        conn.close()
        error = "Code incorrect. Veuillez réessayer."
        return render_template('verify.html', email=email, error=error)

@app.route('/verify', methods=['GET', 'POST'])
def verify():
    if request.method == 'POST':
        email = request.form['email']
        code = request.form['code']

        conn = sqlite3.connect('transfert.db')
        c = conn.cursor()
        c.execute("SELECT verification_code FROM users WHERE email = ?", (email,))
        result = c.fetchone()

        if result and result[0] == code:
            c.execute("UPDATE users SET is_verified = 1 WHERE email = ?", (email,))
            conn.commit()
            conn.close()
            return redirect(url_for('login'))  # Redirige vers la page de connexion après succès
        else:
            conn.close()
            return "Code de vérification incorrect ou utilisateur introuvable."

    return render_template('verify.html')

import webbrowser

if __name__ == '__main__':
    webbrowser.open("http://127.0.0.1:5000/")
    app.run(debug=True)